export enum ProductCategory {
    "all",
    "t-shirts",
    "mugs"
}