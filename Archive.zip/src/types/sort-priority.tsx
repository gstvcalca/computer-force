export enum SortPriority {
    'NEWS',
    'SMALLEST', 
    'BIGGEST',
    'POPULARITY'
}
