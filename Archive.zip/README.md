# npx create-next-app
# > no Tailwind nor imports

# npm install styled-components